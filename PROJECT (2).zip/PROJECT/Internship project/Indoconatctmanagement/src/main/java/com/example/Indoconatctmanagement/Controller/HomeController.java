package com.example.Indoconatctmanagement.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @GetMapping("/Home")
    public String homePage() {
        return "HOME"; // resolves to home.html
    }

    @GetMapping("/addindustry")
    public String addIndustryPage() {
        return "add_industry";

    }

}
