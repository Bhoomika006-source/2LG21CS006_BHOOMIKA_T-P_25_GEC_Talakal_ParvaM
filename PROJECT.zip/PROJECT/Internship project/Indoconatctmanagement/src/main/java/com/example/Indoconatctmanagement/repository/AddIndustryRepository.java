package com.example.Indoconatctmanagement.repository;

import com.example.Indoconatctmanagement.model.Industry;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IndustryRepository extends JpaRepository<Industry, Long> {
}
