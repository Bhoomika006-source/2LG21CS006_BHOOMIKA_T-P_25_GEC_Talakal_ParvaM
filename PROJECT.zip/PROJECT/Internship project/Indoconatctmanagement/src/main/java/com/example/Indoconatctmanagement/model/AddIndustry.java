package com.example.Indoconatctmanagement.model;

import org.springframework.web.multipart.MultipartFile;
import jakarta.persistence.*;

@Entity
@Table(name = "industries")
public class Industry {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String industryName;
    private String industryType;
    private String industryAddress;
    private String industryCity;
    private String industryState;
    private String industryCountry;
    private String industryPhone;

    @Transient
    private MultipartFile industryImage; // Transient: not stored in DB

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public String getIndustryName() {
        return industryName;
    }

    public void setIndustryName(String industryName) {
        this.industryName = industryName;
    }

    public String getIndustryType() {
        return industryType;
    }

    public void setIndustryType(String industryType) {
        this.industryType = industryType;
    }

    public String getIndustryAddress() {
        return industryAddress;
    }

    public void setIndustryAddress(String industryAddress) {
        this.industryAddress = industryAddress;
    }

    public String getIndustryCity() {
        return industryCity;
    }

    public void setIndustryCity(String industryCity) {
        this.industryCity = industryCity;
    }

    public String getIndustryState() {
        return industryState;
    }

    public void setIndustryState(String industryState) {
        this.industryState = industryState;
    }

    public String getIndustryCountry() {
        return industryCountry;
    }

    public void setIndustryCountry(String industryCountry) {
        this.industryCountry = industryCountry;
    }

    public String getIndustryPhone() {
        return industryPhone;
    }

    public void setIndustryPhone(String industryPhone) {
        this.industryPhone = industryPhone;
    }

    public MultipartFile getIndustryImage() {
        return industryImage;
    }

    public void setIndustryImage(MultipartFile industryImage) {
        this.industryImage = industryImage;
    }
}
